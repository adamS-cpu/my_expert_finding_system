package cn.xueden.utils;

import lombok.Data;

/**
 * @author:梁志杰
 * @date:2023/2/20
 * @description:cn.xueden.utils
 * @version:1.0
 */
@Data
public class ResultVo {

    private Long id;

    private String name;
}
