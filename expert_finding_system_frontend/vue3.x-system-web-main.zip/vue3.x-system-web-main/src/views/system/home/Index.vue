<template>
<div>后台首页</div>
</template>

<script>
export default {
  name: "Index"
}
</script>

<style scoped>

</style>
